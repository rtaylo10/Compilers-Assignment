package absyn;

public class NilExp extends Exp {
  public NilExp( int pos) {
    this.pos = pos;
  }
}
