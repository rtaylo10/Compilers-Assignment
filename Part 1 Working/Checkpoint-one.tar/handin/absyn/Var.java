package absyn;

abstract public class Var extends Absyn {
}

